
import requests
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

API_KEY = '846a76edfb6abb4a29fe8dd957d694a4'
CITY = 'Lucknow'
URL = f"http://api.openweathermap.org/data/2.5/forecast?q={CITY}&appid={API_KEY}&units=metric"

response = requests.get(URL)
data = response.json()

forecast_list = data['list']
weather_data = []

for item in forecast_list:
    weather_data.append({
        'Datetime': item['dt_txt'],
        'Temperature (°C)': item['main']['temp'],
        'Humidity (%)': item['main']['humidity'],
        'Wind Speed (m/s)': item['wind']['speed']
    })

df = pd.DataFrame(weather_data)
df['Datetime'] = pd.to_datetime(df['Datetime'])

print(df.head())

plt.figure(figsize=(12, 6))
sns.lineplot(data=df, x='Datetime', y='Temperature (°C)', label='Temperature (°C)')
sns.lineplot(data=df, x='Datetime', y='Humidity (%)', label='Humidity (%)')
sns.lineplot(data=df, x='Datetime', y='Wind Speed (m/s)', label='Wind Speed (m/s)')
plt.title(f"Weather Forecast for {CITY}")
plt.xlabel("Datetime")
plt.ylabel("Values")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.show()

plt.figure(figsize=(12, 6))
sns.barplot(data=df, x='Datetime', y='Temperature (°C)', color='skyblue')
plt.title(f"Temperature Forecast for {CITY}")
plt.xlabel("Datetime")
plt.ylabel("Temperature (°C)")
plt.xticks(rotation=90, fontsize=8)
plt.tight_layout()
plt.show()
