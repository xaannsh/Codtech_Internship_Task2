
Weather Forecast Project - Lucknow

Description:
This project fetches the 5-day weather forecast data for Lucknow using the OpenWeatherMap API. 
It includes temperature, humidity, and wind speed visualizations.

Files Included:
- weather_data.csv: Sample data structured like API output
- line_plot.png: Line chart of temperature, humidity, and wind speed
- bar_plot.png: Bar chart of temperature over time
- Weather_Report_Lucknow.pdf: Complete report with explanation and graphs
- weather_script.py: Python script
- weather_notebook.ipynb: Jupyter notebook version

How to Run:
1. Install required libraries:
   pip install requests pandas matplotlib seaborn fpdf

2. Replace 'YOUR_API_KEY_HERE' with your actual API key in the script.

3. Run weather_script.py or open weather_notebook.ipynb.

API Key:
The API key used in this project is personal. Replace it with your own key if needed.

Author: Auto-generated with OpenAI assistance.
